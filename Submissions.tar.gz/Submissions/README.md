1.I created a new folder which called " Submissions" by using mkdir command
2.Then i used Vi mode to create a new file under Submissions directory. The name is myHungerGames.txt.
3.I used "nano myHungerGames.txt" to enter this file and use ^R and ^T to read the professor's file. Then ^x and save it.
4.I got a file which named "myHungerGames.txt.save". Then I used "mv myHungerGames.txt.save myHungerGames.txt" to change the file name.
5.use nano command and ^w ,^R to replace"Peeta" to my name "Lu"
5.Then Created a new file which named README.md and use nano command to write what I did in this assignment.
6.then use "tar' command to compress the "Submissions" folder.
7.push to github.

